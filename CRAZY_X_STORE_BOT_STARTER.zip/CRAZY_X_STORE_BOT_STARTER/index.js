const TelegramBot = require("node-telegram-bot-api");

const token = process.env.BOT_TOKEN;
if (!token) {
  console.error("Missing BOT_TOKEN environment variable.");
  process.exit(1);
}

const bot = new TelegramBot(token, { polling: true });

bot.onText(/^\/start(?:@\w+)?$/, (msg) => {
  bot.sendMessage(
    msg.chat.id,
    "🔥 Welcome to CRAZY X STORE XMD BOT!\n\n" +
      "এই বটের প্রাথমিক সংস্করণ চালু হয়েছে।\n" +
      "WhatsApp Pairing এখনো যুক্ত করা হয়নি।\n\n" +
      "Commands:\n/start - বট চালু\n/help - কমান্ডের তালিকা\n/about - বট সম্পর্কে"
  );
});

bot.onText(/^\/help(?:@\w+)?$/, (msg) => {
  bot.sendMessage(
    msg.chat.id,
    "📋 Available commands:\n/start\n/help\n/about\n\n" +
      "WhatsApp pairing feature is not configured yet."
  );
});

bot.onText(/^\/about(?:@\w+)?$/, (msg) => {
  bot.sendMessage(
    msg.chat.id,
    "CRAZY X STORE XMD BOT\nStarter version.\n" +
      "WhatsApp pairing is not active in this version."
  );
});

bot.on("polling_error", (error) => {
  console.error("Telegram polling error:", error.message);
});

console.log("CRAZY X STORE bot is running.");
